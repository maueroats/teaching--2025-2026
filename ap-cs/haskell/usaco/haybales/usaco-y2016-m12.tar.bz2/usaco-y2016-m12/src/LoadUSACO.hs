module LoadUSACO
where

import Control.Monad
import Control.Applicative
import Control.DeepSeq
import System.IO

findNQ :: [[Int]] -> (Int, Int)
findNQ line_data = (line!!0, line!!1)
    where line = head line_data

findQs :: [[Int]] -> [Int]
findQs line_data = line_data !! 1

findNPairs :: Int -> [[Int]] -> [(Int,Int)]
findNPairs n line_data = map (\v -> (v!!0, v!!1)) $ drop 2 line_data

loadFileData' :: [String] -> [[Int]]
loadFileData' raw_line_data = liftM read <$> words <$> raw_line_data

loadFileData :: String -> [[Int]]
loadFileData everything = loadFileData' $ lines everything

loadFile1 :: Handle -> IO [[Int]]
loadFile1 handle = do
                      contents <- hGetContents handle
                      return $!! loadFileData contents

loadFile :: String -> IO [[Int]]
loadFile filename = withFile filename ReadMode loadFile1

