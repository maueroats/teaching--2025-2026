module HayBales
where


hayBales1 :: [Int] -> (Int,Int) -> Int
hayBales1 qq (s,e) = length $ filter (\x -> s <= x && x <= e) qq

