# Haybales

[Counting Hay Bales](http://usaco.org/index.php?page=viewproblem2&cpid=666), Bronze 1, December 2016 

Problem: count how many hay bales in a given interval.

Issues: There are 100,000 different intervals to check, so you will find a 
naive strategy takes too long. Make sure you try the basic strategy first!

## Provided

* The input-reading function `loadFile :: String -> IO [[Int]]`
  produces an array when given the filename.

* The main method gets the name of a file from the first argument on
the command line.  You could replace `args <- getArgs` with 
`let args = "3.in"` if you do not want to use the command line.

* There are no separate testing functions written!

## Compiler setup

If you have [Stack](https://haskell-lang.org/get-started), you should
be able to `stack build` and then `stack exec usaco-y2016-m12
"data/3.in"` to run it. Otherwise, try copy and pasting the functions
from the `src` and `app` directories into one big file.







