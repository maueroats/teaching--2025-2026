module Main where

import LoadUSACO
import HayBales
import Data.List
import System.Environment

workOne qq (ns,ne) = do
--  putStrLn $ "[" ++ (show ns) ++ "," ++ (show ne) ++ "]"
  putStrLn $ show $ hayBales1 qq (ns,ne)
    
main :: IO ()
main = do
  args <- getArgs
  filedata <- loadFile (args!!0)
  let (n,q) = findNQ filedata
      qs    = sort $ findQs filedata
      npairs= findNPairs n filedata
--  putStrLn $ "N = " ++ (show n)
--  putStrLn $ "Q = " ++ (show q)
--  mapM_ (\oneq -> putStrLn $ "pt :" ++ (show oneq)) qs
  mapM_ (workOne qs) npairs
           
